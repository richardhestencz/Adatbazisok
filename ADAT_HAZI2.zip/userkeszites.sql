CREATE User maszk3 WITHOUT login;
Grant SELECT ON Hazi2 to maszk3