Execute AS User='maszk3';
SELECT * FROM Hazi2